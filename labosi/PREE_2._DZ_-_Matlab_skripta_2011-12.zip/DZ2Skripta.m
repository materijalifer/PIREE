%pogonsko stanje na kraju voda; induktivno opterecenje

%unesi svoje podatke, kod je pisan tako da imas i me�urezultate, sve struje
%su u kA, svi naponi u kV, sve snage u MVA, 

%OZNAKE SU
%V1,V2 fazni napon pocetak voda,kraj, U1,U2 linijski napon I1,I2 struja
%S1,S2,dS snaga pocetak,kraj, gubitak snage na vodu 
%za pojedini dio zadatka gore navedene velicine su indeksirane 
%a)nema indeksa b)I1ph V2ph dSph c)I1Zc V2Zc dSZc d)

%postupak gledajte iz dokumenta, razultate gledajte u workspaceu(desni
%gornji dio matlaba) a grafovi ce sami iskocit
%slike si morate sami uvecavati i dotjerivati to ja ne mogu unaprijed
%znati... rezultati su sgurno tocni, nadam se da sam pomogao Sretno! :)

clc
clear all
R1=0.097
X1=0.353
G1=0
B1=3.359e-6
L=115 %duljina voda
x=[0:0.01:L]; %vektor duljine voda koji je potrebno dati naredbi plot da iscrta napon i struju
faktorsnage=0.813 %INDUKTIVNO
s2=183.6 % modul snage na kraju voda (u MVA)
U2=215 %linijski napon na kraju voda (u kV)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%prora�un osnovnih parametara voda
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Z1=R1+i*X1
Y1=0+i*B1
Zc=sqrt(Z1/Y1) %karakteristicna impedancija voda
gama=sqrt(Z1*Y1) %dubina prodiranja
theta=gama*L %argument sh i ch funkcija u valnoj jednadjbi
V2=U2/sqrt(3) %fazni napon na kraju voda
phi=acos(faktorsnage) %kut opterecenja

%a dio- odrediti prilike na po�etku voda i gubitke snage uz zadano pogonsko
%stanje na kraju voda
S2=s2*(cos(phi)+i*sin(phi))% ZA KAPACITIVNI OPTERE�ENJE OVDJE UMJESTO PLUSA STAVITI MINUS
I2=conj(S2/(3*V2))
V1=(V2*cosh(theta)+Zc*I2*sinh(theta))
U1=sqrt(3)*V1
I1=(I2*cosh(theta)+V2/Zc*sinh(theta))%fazni, linijski napon i struja na pocetku voda
S1=3*V1*conj(I1)%snaga na pocetku voda
dS=S1-S2 % gubitak snage na vodu za a dio 


%%%%%%%%%%%%%%%%%%%%%%%%%
%crtanje grafova za a dio
close all

tempU2=sqrt(3)*(V1*cosh(gama*x)-Zc*I1*sinh(gama*x))
figure
plot(x,abs(tempU2), 'b'),grid on

title('Valni oblik linijskog napona na vodu za slucaj a)')
xlabel('Duljina voda [km]')

tempI2=(I1*cosh(gama*x)-(V1/Zc)*sinh(gama*x))
figure
plot(x,abs(tempI2), 'r'),grid on

title('Valni oblik struje na vodu za slucaj a)')
ylabel('Struja [kA]')
xlabel('Duljina voda [km]')

%B dio- b)	Prazni hod, zadano stanje sa kraja voda se sada nalazi na
%pocetku voda
V1ph=U2/sqrt(3)
I1ph=(U2/(Zc*sqrt(3)))*(sinh(theta)/cosh(theta))%izvedena formula iz uvjeta 
%da je struja na kraju voda jednaka 0
S1ph=3*V1ph*conj(I1ph)%snaga na pocetku voda


V2ph=V1ph*cosh(theta)-Zc*I1ph*sinh(theta)% napon na kraju voda (u ph) -> I2=0
U2ph=V2ph*sqrt(3)
dSph=S1ph %gubitak snage na vodu u ph jednak je snazi na pocetku voda


%%%%%%%%%%%%%%%%%%%%%%%%%
%crtanje grafova za b dio

tempU2ph=sqrt(3)*(V1ph*cosh(gama*x)-Zc*I1ph*sinh(gama*x))
figure
plot(x,abs(tempU2ph), 'b'),grid on

title('Valni oblik linijskog napona na vodu za slucaj praznog hoda')
xlabel('Duljina voda [km]')

tempI2ph=(I1ph*cosh(gama*x)-(V1ph/Zc)*sinh(gama*x))
figure
plot(x,abs(tempI2ph), 'r'),grid on

title('Valni oblik struje na vodu za slucaj praznog hoda na kraju voda')
ylabel('Struja [kA]')
xlabel('Duljina voda [km]')

%C dio-Vod zaklju�en karakteristi�nom impedancijom, zadano stanje sa kraja 
%voda se sada nalazi na pocetku voda
V1Zc=U2/sqrt(3)
I1Zc=(V1Zc/Zc) %formula koja je izvedena u word dokumentu, vrijedi samo 
%za vod zakljucen sa Zc
S1Zc=conj(I1Zc)*3*V1Zc

I2Zc=(I1Zc*cosh(theta)-(V1Zc/Zc)*sinh(theta))
V2Zc=I2Zc*Zc %vrijedi jer je vod zakljucen sa Zc
U2Zc=V2Zc*sqrt(3)

S2Zc=conj(I2Zc)*3*V2Zc
dSZc=S1Zc-S2Zc%gubitak snage u slucaju voda zakljucenog sa Zc

%%%%%%%%%%%%%%%%%%%%%%%%%
%crtanje grafova za c dio

tempI2Zc=(I1Zc*cosh(gama*x)-(V1Zc/Zc)*sinh(gama*x))
figure
plot(x,abs(tempI2Zc), 'r'),grid on

title('Valni oblik struje za slucaj voda zakljucenog sa Zc')
ylabel('Struja [kA]')
xlabel('Duljina voda [km]')

tempU2Zc=sqrt(3)*(tempI2Zc*Zc)

figure
plot(x,abs(tempU2Zc), 'b'),grid on

title('Valni oblik linijskog napona na vodu za slucaj voda zakljucenog sa Zc')
xlabel('Duljina voda [km]')

%%D dio zadatka	Duljina voda za 5% ve�i napon izlaza u praznom hodu

L_pet_posto=abs(acosh(1.05)/gama) % u kilometrima 
